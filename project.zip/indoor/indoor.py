print(input().strip().lower())
