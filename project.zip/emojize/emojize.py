def main():
    import emoji
    user = input("Input: ")
    output = emoji.emojize(user, language = "alias")
    print("Output:", output)











main()
