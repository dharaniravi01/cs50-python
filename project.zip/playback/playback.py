print(input().strip().replace(' ','...'))
